// import { Field, ObjectType } from "@nestjs/graphql";
// import { Entity, PrimaryGeneratedColumn } from "typeorm";

// @ObjectType()
// @Entity()
export class IllnessHystory {
    // @PrimaryGeneratedColumn()
    // @Field(() => Number)
    // id: number;

    // @Field()
    // @Field()
    // @Field()
    // @Field()
}
// 