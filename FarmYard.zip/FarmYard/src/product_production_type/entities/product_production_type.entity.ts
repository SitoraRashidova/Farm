export class ProductProductionType {}
