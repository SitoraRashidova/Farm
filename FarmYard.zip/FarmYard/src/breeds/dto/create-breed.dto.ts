export class CreateBreedDto {}
