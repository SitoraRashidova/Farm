export class CreateFoodDto {}
