export class CreateAnimalConditionDto {}
