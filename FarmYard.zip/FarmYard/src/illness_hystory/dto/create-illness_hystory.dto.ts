export class CreateIllnessHystoryDto {}
