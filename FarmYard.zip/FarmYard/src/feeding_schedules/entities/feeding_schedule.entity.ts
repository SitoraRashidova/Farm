export class FeedingSchedule {}
