export class CreateFeedingScheduleDto {}
