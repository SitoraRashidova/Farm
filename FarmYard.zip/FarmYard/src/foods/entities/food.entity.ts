export class Food {}
