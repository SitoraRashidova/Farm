export class VaccinationHystory {}
