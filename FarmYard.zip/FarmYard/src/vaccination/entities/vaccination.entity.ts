export class Vaccination {}
