export class CreateIllnessTypeDto {}
