export class IllnessType {}
