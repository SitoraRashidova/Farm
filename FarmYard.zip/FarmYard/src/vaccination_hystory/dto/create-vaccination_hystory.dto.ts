export class CreateVaccinationHystoryDto {}
