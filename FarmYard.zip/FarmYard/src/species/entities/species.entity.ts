export class Species {}
