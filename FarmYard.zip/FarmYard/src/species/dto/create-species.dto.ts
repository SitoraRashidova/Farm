export class CreateSpeciesDto {}
