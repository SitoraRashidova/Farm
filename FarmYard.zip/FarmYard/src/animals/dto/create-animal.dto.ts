export class CreateAnimalDto {}
