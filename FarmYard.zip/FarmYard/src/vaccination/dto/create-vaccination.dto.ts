export class CreateVaccinationDto {}
