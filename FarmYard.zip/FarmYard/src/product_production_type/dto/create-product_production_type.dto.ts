export class CreateProductProductionTypeDto {}
